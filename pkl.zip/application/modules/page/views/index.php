<script>
    $(document).ready(function() {
        $(".preloader").fadeOut();
    })
</script>
<section class="content">
	<div class="error-page">
		<h2 class="headline text-yellow"> 403</h2>

		<div class="error-content">
			<h3><i class="fa fa-warning text-yellow"></i> Hayo Mau ngapain ???</h3>

			<p>
				<a href="<?= site_url('admin') ?>">Balik ya !</a>
			</p>
		</div>
		<!-- /.error-content -->
	</div>
	<!-- /.error-page -->
</section>