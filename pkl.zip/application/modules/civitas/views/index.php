<section class="content-header">
	<h1>
		Civitas
	</h1>
</section>
<section class="content">
	<div class="row">
		<div class="col-xs-12">
			<div class="box">
				<div class="box-header">
					<h3 class="box-title">Role Management</h3>
					<br>
					<hr>
					<button type="button" class="btn btn-success btn-sm" id="tambah"><i class="fa fa-plus"></i> Tambah</button>
				</div>
				<div class="box-body">
					<div class="table-responsive">
						<table class="table table-bordered table-sm" id="myData" width="100%">
							<thead class="thead-dark">
								<tr>
									<th>No</th>
									<th>NIK</th>
									<th>Nama Lengkap</th>
									<th>Alamat</th>
									<th>No Telepon</th>
									<th>Email</th>
									<th>Website</th>
									<th>Foto</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody id="data">
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- modal -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Tambah</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form id="form">
				<div class="modal-body">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="nik">NIK</label>
								<input type="number" name="nik" id="nik" class="form-control form-control-sm" placeholder="NIK" required>
							</div>
							<div class="form-group">
								<label for="nama">Nama Lengkap</label>
								<input type="text" name="nama" id="nama" class="form-control form-control-sm" placeholder="Nama Lengkap" required>
							</div>
							<div class="form-group">
								<label for="alamat">Alamat</label>
								<textarea name="alamat" id="alamat" cols="30" rows="3" class="form-control" placeholder="Alamat" required></textarea>
							</div>
							<div class="form-group">
								<label for="no_hp">No Telepon</label>
								<input type="number" name="no_hp" id="no_hp" class="form-control form-control-sm" placeholder="No Telepon" required>
							</div>
							<div class="form-group">
								<label for="email">Email</label>
								<input type="email" name="email" id="email" class="form-control form-control-sm" placeholder="Email" required>
							</div>
							<div class="form-group">
								<label for="web">Website</label>
								<input type="text" name="web" id="web" class="form-control form-control-sm" placeholder="Website" required>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="gambar">Foto</label>
							</div>
							<div class="form-group">
								<label for="gambar" class="col-sm-4" id="reset"><img class="img-fluid" src="<?= base_url() ?>assets/img/noimage.png" id="output" width="150px" height="170px"></label>
								<input type="file" class="custom-file-input" accept="image/*" onchange="loadFile(event)" id="gambar" name="gambar">
							</div>
							<div id="add">
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
					<button type="submit" class="btn btn-primary" id="btn">Tambah</button>
				</div>
			</form>
		</div>
	</div>
</div>

<script>
	var loadFile = function(event) {
		var output = document.getElementById('output');
		output.src = URL.createObjectURL(event.target.files[0]);
	};
	$(document).ready(function() {
		const form = $('.modal-body').html();
		$('#myData').DataTable({
			"processing": true,
			"serverSide": true,
			"order": [],
			"ajax": {
				"url": "<?= site_url('civitas/getLists'); ?>",
				"type": "POST"
			},
			"columnDefs": [{
				"targets": [0],
				"orderable": false
			}]
		});
		$('#tambah').click(function() {
			$('.modal-body').html(form);
			aksi = `<input type="hidden" name="aksi" id="aksi" value="tambah">
			<div class="form-group">
			<label for="username">Username</label>
			<input type="text" name="username" id="username" class="form-control form-control-sm" placeholder="Username" required>
			</div>
			<div class="form-group">
			<label for="password">Password</label>
			<input type="password" name="password" id="password" class="form-control form-control-sm" placeholder="Password" required>
			</div>
			<div class="form-group">
			<label for="password2">Confirm Password</label>
			<input type="password" name="password2" id="password2" class="form-control form-control-sm" placeholder="Password" required>
			</div>
			`;
			$('#add').html(aksi);
			$('#modal').find('h5').html('Tambah')
			$('#modal').find('#btn').html('Tambah')
			$('#modal').modal('show');
		});
		$('#data').on('click', '.edit', function() {
			$('.modal-body').html(form);
			aksi = `
			<input type="hidden" name="aksi" id="aksi" value="edit">
			<input type="hidden" name="gambarLama" id="gambarLama" value="${$(this).data('foto')}">
            <input type="hidden" name="id" id="id" value="${$(this).data('civitas')}">`;
			$('#add').html(aksi);
			$('#modal').find('h5').html('Edit');
			$('#modal').find('#btn').html('Edit');
			$('#nik').val($(this).data('nik'));
			$('#nama').val($(this).data('nama'));
			$('#alamat').val($(this).data('alamat'));
			$('#no_hp').val($(this).data('tlp'));
			$('#email').val($(this).data('email'));
			$('#web').val($(this).data('website'));
			$('#reset').html(`
			<img src="<?=base_url()?>/assets/img/profile/${$(this).data('foto')}" alt="foto" width="150px" height="170px">	
			`)
			$('#modal').modal('show');
		});
		$('#data').on('click', '.hapus', function() {
			$('.modal-body').html(form);
			aksi = `<input type="hidden" name="aksi" id="aksi" value="hapus">
                <input type="hidden" name="id" id="id" value="${$(this).data('civitas')}">
                <h3>Apakah Anda Yakin ?</h3>`;
			$('.modal-body').html(aksi);
			$('#modal').find('h5').html('Hapus')
			$('#modal').find('#btn').html('Hapus')
			$('#modal').modal('show');
		});
		$('#form').submit(function(e) {
			e.preventDefault();
			$.ajax({
				url: '<?= site_url('civitas/aksi') ?>',
				type: 'post',
				data: new FormData(this),
				dataType: 'json',
				processData: false,
				contentType: false,
				async: false,
				success: result => {
					if (result.status == true) {
						toastr["success"](result.pesan);
					} else {
						toastr["error"](result.pesan);
					}
					$('#myData').DataTable().ajax.reload();
					$('#modal').modal('hide');
				}
			})
		})
	});
</script>